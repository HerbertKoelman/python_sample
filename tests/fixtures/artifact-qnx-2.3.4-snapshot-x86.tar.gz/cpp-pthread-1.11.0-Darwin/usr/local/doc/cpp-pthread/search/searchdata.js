var indexSectionsWithContent =
{
  0: "_acdeghijlmnopqrstuw~",
  1: "aclmpqrstw",
  2: "p",
  3: "celmprst",
  4: "acdegijlmnopqrstuw~",
  5: "_",
  6: "r",
  7: "ct",
  8: "ant",
  9: "c",
  10: "chp",
  11: "cetu",
  12: "dw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "related",
  10: "defines",
  11: "groups",
  12: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Friends",
  10: "Macros",
  11: "Modules",
  12: "Pages"
};

