var searchData=
[
  ['errors_20and_20exceptions_217',['Errors and exceptions',['../group__exception.html',1,'']]]
];
